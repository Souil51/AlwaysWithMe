using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyWithAnimation : MonoBehaviour
{
    public void DestroyObject()
    {
        Destroy(this.gameObject);
    }
}
